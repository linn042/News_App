package network

object ApiConstants {
    const val BASE_URL = "https://newsapi.org"
    const val VERSION = "v2"
    const val API_KEY = "8e64ee5e79f84d09b64e7c6b4683c738"
    const val COUNTRY = "us"
}
